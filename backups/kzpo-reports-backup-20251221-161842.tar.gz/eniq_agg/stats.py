from __future__ import annotations

from datetime import datetime, timedelta
from typing import Dict, Optional, List, Any

import pytz
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import Analysis


def normalize_date(dt: datetime, tz: str) -> datetime:
    zone = pytz.timezone(tz)
    if dt.tzinfo is None:
        return zone.localize(dt)
    return dt.astimezone(zone)


def get_score(a: Analysis) -> Optional[float]:
    res = a.result_json or {}
    for key in ("Final Score", "Загальна оцінка"):
        if key in res:
            try:
                return float(res[key])
            except Exception:
                continue
    return None


def daily_metrics(
    session: Session, representative: str, tz: str
) -> Dict[str, Optional[float]]:
    now = datetime.now(pytz.timezone(tz))
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    today_end = today_start + timedelta(days=1)

    base_query = select(Analysis).where(
        Analysis.representative == representative,
        Analysis.call_date.is_not(None),
        Analysis.call_date >= today_start,
        Analysis.call_date < today_end,
    )
    rows: List[Analysis] = session.scalars(base_query).all()
    calls_today = len(rows)
    avg_duration = (
        sum(filter(None, [r.duration_minutes for r in rows])) / calls_today
        if calls_today
        else 0
    )
    errors = [r for r in rows if (get_score(r) is not None and get_score(r) < 4)]

    # average per day over last 30 days
    month_start = today_start - timedelta(days=30)
    month_rows = session.scalars(
        select(Analysis.call_date).where(
            Analysis.representative == representative,
            Analysis.call_date.is_not(None),
            Analysis.call_date >= month_start,
            Analysis.call_date < today_end,
        )
    ).all()
    calls_30d = len(month_rows)
    avg_per_day_30d = calls_30d / 30.0

    return {
        "calls_today": calls_today,
        "avg_duration": avg_duration,
        "avg_per_day_30d": avg_per_day_30d,
        "errors": errors,
    }


def list_representatives(session: Session) -> List[str]:
    reps = session.execute(
        select(Analysis.representative)
        .where(Analysis.representative.is_not(None))
        .distinct()
        .order_by(Analysis.representative)
    ).scalars()
    return [r for r in reps if r]


def weekly_org_metrics(session: Session, tz: str) -> Dict[str, Any]:
    now = datetime.now(pytz.timezone(tz))
    start = now - timedelta(days=7)
    rows: List[Analysis] = session.scalars(
        select(Analysis).where(
            Analysis.call_date.is_not(None),
            Analysis.call_date >= start,
            Analysis.call_date <= now,
        )
    ).all()
    total = len(rows)
    avg_dur = (
        sum(filter(None, [r.duration_minutes for r in rows])) / total if total else 0
    )
    errors = [r for r in rows if (get_score(r) is not None and get_score(r) < 4)]
    call_filter_irrel = sum(
        1 for r in rows if (r.result_json or {}).get("Call_Filter") == "Irrelevant"
    )

    rep_counts = session.execute(
        select(Analysis.representative, func.count())
        .where(
            Analysis.call_date.is_not(None),
            Analysis.call_date >= start,
            Analysis.call_date <= now,
        )
        .group_by(Analysis.representative)
        .order_by(func.count().desc())
    ).all()
    top_reps = [(r[0], r[1]) for r in rep_counts if r[0]][:5]

    return {
        "total": total,
        "avg_duration": avg_dur,
        "errors": errors,
        "irrelevant": call_filter_irrel,
        "top_reps": top_reps,
    }


def day_stats_for_rep(
    session: Session, representative: str, tz: str, day_offset: int = 0
) -> Dict[str, Any]:
    """Stats for specific day (offset 0=today, 1=yesterday)."""
    zone = pytz.timezone(tz)
    now = datetime.now(zone)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(
        days=day_offset
    )
    end = start + timedelta(days=1)
    rows: List[Analysis] = session.scalars(
        select(Analysis).where(
            Analysis.representative == representative,
            Analysis.call_date.is_not(None),
            Analysis.call_date >= start,
            Analysis.call_date < end,
        )
    ).all()
    total = len(rows)
    avg_dur = (
        sum(filter(None, [r.duration_minutes for r in rows])) / total if total else 0
    )
    scores = [get_score(r) for r in rows if get_score(r) is not None]
    avg_score = sum(scores) / len(scores) if scores else None
    return {"total": total, "avg_duration": avg_dur, "avg_score": avg_score}


def admin_snapshot(session: Session, tz: str, window_days: int = 30, recent_limit: int = 5) -> Dict[str, Any]:
    """Aggregated stats for admins across org."""
    zone = pytz.timezone(tz)
    now = datetime.now(zone)
    start_today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    start_yesterday = start_today - timedelta(days=1)
    start_7 = now - timedelta(days=7)
    start_window = now - timedelta(days=window_days)

    rows: List[Analysis] = session.scalars(
        select(Analysis).where(
            Analysis.call_date.is_not(None),
            Analysis.call_date >= start_window,
            Analysis.call_date <= now,
        )
    ).all()

    def _filter(start: datetime, end: datetime) -> List[Analysis]:
        return [
            r
            for r in rows
            if r.call_date and start <= normalize_date(r.call_date, tz) < end
        ]

    today_rows = _filter(start_today, start_today + timedelta(days=1))
    yesterday_rows = _filter(start_yesterday, start_today)
    week_rows = _filter(start_7, now)

    def _avg_duration(items: List[Analysis]) -> float:
        vals = [r.duration_minutes for r in items if r.duration_minutes]
        return sum(vals) / len(vals) if vals else 0

    def _error_items(items: List[Analysis]) -> List[Analysis]:
        return [r for r in items if (get_score(r) is not None and get_score(r) < 4)]

    rep_counts = {}
    rep_avg_dur = {}
    for r in week_rows:
        rep = r.representative or "—"
        rep_counts[rep] = rep_counts.get(rep, 0) + 1
        if r.duration_minutes:
            rep_avg_dur.setdefault(rep, []).append(r.duration_minutes)
    rep_avg_dur = {k: sum(v) / len(v) for k, v in rep_avg_dur.items()}

    recent_calls = (
        session.scalars(
            select(Analysis)
            .where(Analysis.call_date.is_not(None))
            .order_by(Analysis.call_date.desc())
            .limit(recent_limit)
        ).all()
    )

    recent_errors = [
        r for r in session.scalars(
            select(Analysis)
            .where(Analysis.call_date.is_not(None))
            .order_by(Analysis.call_date.desc())
            .limit(100)
        ).all()
        if get_score(r) is not None and get_score(r) < 4
    ][:recent_limit]

    return {
        "window_days": window_days,
        "today": {
            "total": len(today_rows),
            "avg_duration": _avg_duration(today_rows),
            "errors": _error_items(today_rows),
        },
        "yesterday": {
            "total": len(yesterday_rows),
            "avg_duration": _avg_duration(yesterday_rows),
            "errors": _error_items(yesterday_rows),
        },
        "week": {
            "total": len(week_rows),
            "avg_duration": _avg_duration(week_rows),
            "errors": _error_items(week_rows),
        },
        "window": {
            "total": len(rows),
            "avg_duration": _avg_duration(rows),
            "errors": _error_items(rows),
        },
        "per_rep": {
            rep: {
                "calls_7d": rep_counts.get(rep, 0),
                "avg_duration_7d": rep_avg_dur.get(rep, 0),
            }
            for rep in rep_counts
        },
        "top_reps_7d": sorted(rep_counts.items(), key=lambda x: x[1], reverse=True)[:5],
        "recent_calls": [
            {
                "id": r.id,
                "rep": r.representative,
                "client": (r.metadata_json or {}).get("Customer"),
                "score": get_score(r),
                "summary": r.summary or r.title,
                "url": r.external_url,
                "date": r.call_date,
            }
            for r in recent_calls
        ],
        "recent_errors": [
            {
                "id": r.id,
                "rep": r.representative,
                "client": (r.metadata_json or {}).get("Customer"),
                "score": get_score(r),
                "summary": r.summary or r.title,
                "url": r.external_url,
                "date": r.call_date,
            }
            for r in recent_errors
        ],
    }
