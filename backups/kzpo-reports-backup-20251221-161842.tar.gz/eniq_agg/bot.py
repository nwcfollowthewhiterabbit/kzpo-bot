import asyncio
import json
import re
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

import pytz
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    ReplyKeyboardMarkup,
    KeyboardButton,
    ReplyKeyboardRemove,
)
from sqlalchemy import select, func
from openai import OpenAI

from .config import settings
from .db import get_session
from .ingest import ensure_schema, ingest_all
from .models import Analysis, User, AdminLog, InteractionLog
from .stats import (
    daily_metrics,
    list_representatives,
    get_score,
    weekly_org_metrics,
    day_stats_for_rep,
    admin_snapshot,
)
from .tools import (
    get_departments,
    get_calls,
    get_metrics,
    get_call_summary,
)


pending_actions: Dict[int, Dict[str, Any]] = {}
_ingest_lock = asyncio.Lock()
_openai_client: Optional[OpenAI] = None


def get_openai_client() -> Optional[OpenAI]:
    global _openai_client
    if _openai_client or not settings.openai_api_key:
        return _openai_client
    _openai_client = OpenAI(api_key=settings.openai_api_key)
    return _openai_client


def _safe_json_loads(text: str) -> Optional[dict]:
    try:
        cleaned = text.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.strip("`")
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        return json.loads(cleaned)
    except Exception:
        return None


def compute_rep_stats(representative: str) -> Dict[str, Any]:
    with get_session() as session:
        today = day_stats_for_rep(session, representative, settings.report_timezone, day_offset=0)
        yesterday = day_stats_for_rep(session, representative, settings.report_timezone, day_offset=1)
    return {"today": today, "yesterday": yesterday}


def compute_admin_stats() -> Dict[str, Any]:
    with get_session() as session:
        return admin_snapshot(session, settings.report_timezone)


def count_calls_between(start: datetime, end: datetime) -> int:
    with get_session() as session:
        return (
            session.scalar(
                select(func.count())
                .select_from(Analysis)
                .where(
                    Analysis.call_date.is_not(None),
                    Analysis.call_date >= start,
                    Analysis.call_date < end,
                )
            )
            or 0
        )


def count_calls_for_day(offset_days: int = 0) -> int:
    zone = pytz.timezone(settings.report_timezone)
    now = datetime.now(zone)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=offset_days)
    end = start + timedelta(days=1)
    start_naive, end_naive = start.replace(tzinfo=None), end.replace(tzinfo=None)
    return count_calls_between(start_naive, end_naive)


def count_calls_last_days(days: int) -> int:
    """Count calls for the last N days including today."""
    days = max(1, min(days, 90))
    zone = pytz.timezone(settings.report_timezone)
    now = datetime.now(zone)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days - 1)
    end = now.replace(hour=23, minute=59, second=59, microsecond=999999)
    return count_calls_between(start.replace(tzinfo=None), end.replace(tzinfo=None))


def daily_counts_last_days(days: int) -> List[Dict[str, Any]]:
    days = max(1, min(days, 90))
    zone = pytz.timezone(settings.report_timezone)
    now = datetime.now(zone)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(days=days - 1)
    end = now.replace(hour=23, minute=59, second=59, microsecond=999999)
    with get_session() as session:
        rows = session.execute(
            select(func.date(Analysis.call_date).label("d"), func.count().label("cnt"))
            .where(
                Analysis.call_date.is_not(None),
                Analysis.call_date >= start.replace(tzinfo=None),
                Analysis.call_date <= end.replace(tzinfo=None),
            )
            .group_by(func.date(Analysis.call_date))
            .order_by(func.date(Analysis.call_date).asc())
        ).all()
    return [{"date": str(r[0]), "calls": r[1]} for r in rows]


def is_stats_query(text: str) -> bool:
    """Rudimentary intent check: respond only to статистика/звонки queries."""
    t = (text or "").lower()
    keywords = ["звон", "call", "вызов", "стат", "metrics", "анализ", "отчет", "report", "дней", "day", "недел"]
    return any(k in t for k in keywords)


def log_interaction(
    chat_id: int,
    user: Optional[User],
    question: str,
    answer: str,
    is_error: bool = False,
    reason: Optional[str] = None,
    meta: Optional[dict] = None,
) -> None:
    with get_session() as session:
        session.add(
            InteractionLog(
                user_id=user.id if user else None,
                chat_id=str(chat_id) if chat_id else None,
                question=question,
                answer=answer,
                is_error=is_error,
                reason=reason,
                meta=meta,
            )
        )


def first_call_today() -> Optional[Analysis]:
    zone = pytz.timezone(settings.report_timezone)
    now = datetime.now(zone)
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    start_naive = start.replace(tzinfo=None)
    end_naive = start_naive + timedelta(days=1)
    with get_session() as session:
        return session.scalar(
            select(Analysis)
            .where(
                Analysis.call_date.is_not(None),
                Analysis.call_date >= start_naive,
                Analysis.call_date < end_naive,
            )
            .order_by(Analysis.call_date.asc())
        )


async def run_planner(question: str, admin_mode: bool) -> Optional[Dict[str, Any]]:
    client = get_openai_client()
    if not client:
        return None
    system_prompt = (
        "Ты работаешь как планировщик. Отвечай ТОЛЬКО JSON без пояснений.\n"
        "Сначала выбери инструмент, который нужен для ответа, и верни команду вида:\n"
        '{"action":"get_departments","params":{"date_from":"today","date_to":"today"}}\n'
        'или {"action":"get_calls","params":{"filters":{"date_from":"today"},"sort":{"field":"call_date","direction":"asc"},"limit":1}}\n'
        'Если вопрос про отделы/департаменты/направления — всегда используй get_departments.\n'
        'Если про первый/последний/длинный звонок — get_calls c sort.\n'
        'Если про метрики по группам — get_metrics с group_by.\n'
        'Если про разрез по дням/последние N дней — используй get_metrics с group_by="date" и нужным диапазоном дат.\n'
        'Не придумывай данные и не отвечай текстом. Если нет подходящего инструмента — верни null.\n'
    )
    try:
        resp = await asyncio.to_thread(
            client.chat.completions.create,
            model=settings.openai_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question},
            ],
            max_tokens=200,
        )
        content = resp.choices[0].message.content or ""
        data = _safe_json_loads(content)
        if isinstance(data, dict) and data.get("action"):
            return data
    except Exception:
        return None
    return None


def execute_tool(command: Dict[str, Any]) -> Dict[str, Any]:
    action = command.get("action")
    params = command.get("params") or {}
    with get_session() as session:
        if action == "get_departments":
            return {"action": action, "result": get_departments(session, settings.report_timezone, params.get("date_from"), params.get("date_to"))}
        if action == "get_calls":
            return {
                "action": action,
                "result": get_calls(
                    session,
                    settings.report_timezone,
                    filters=params.get("filters"),
                    sort=params.get("sort"),
                    limit=int(params.get("limit") or 5),
                ),
            }
        if action == "get_metrics":
            return {
                "action": action,
                "result": get_metrics(
                    session,
                    settings.report_timezone,
                    date_from=params.get("date_from"),
                    date_to=params.get("date_to"),
                    group_by=params.get("group_by") or params.get("groupBy") or "department",
                ),
            }
        if action == "get_call_summary":
            return {
                "action": action,
                "result": get_call_summary(session, int(params.get("call_id"))),
            }
    return {"action": action, "result": None}


async def run_composer(question: str, tool_payload: Dict[str, Any], lang_ru: bool) -> str:
    client = get_openai_client()
    if not client:
        # simple fallback summary
        res = tool_payload.get("result") or {}
        if isinstance(res, dict) and "calls" in res and res["calls"]:
            first = res["calls"][0]
            base = f"{first.get('date')} {first.get('rep') or '-'}: {first.get('summary') or '-'} ({first.get('url') or '-'})"
            return base
        return "Данные получены, но не удалось сформировать ответ без LLM." if lang_ru else "Data fetched, but cannot compose answer without LLM."
    system_prompt = (
        "Ты отвечаешь пользователю, используя только предоставленный результат инструмента. "
        "Не выдумывай данных. Если списки пустые — скажи, что за выбранный период нет данных. "
        "Не добавляй комментарии про активность/оценки, которых нет в данных. "
        "Отвечай только на запрошенный аспект, не добавляй другие метрики, если их не просили. "
        "Дай короткий ответ (2-4 предложения) на языке вопроса."
    )
    content = f"QUESTION: {question}\nDATA: {json.dumps(tool_payload, default=str, ensure_ascii=False)}"
    try:
        resp = await asyncio.to_thread(
            client.chat.completions.create,
            model=settings.openai_model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": content},
            ],
            max_tokens=250,
        )
        return resp.choices[0].message.content.strip()
    except Exception:
        return "Не удалось сформировать ответ." if lang_ru else "Could not compose answer."


async def build_chat_reply(user: User, question: str, admin_mode: bool = False) -> str:
    user_stats = compute_rep_stats(user.representative_name)
    admin_stats = compute_admin_stats() if admin_mode else None
    client = get_openai_client()
    # simple language guess
    is_cyr = bool(re.search("[А-Яа-яЁёІіЇїЄєҐґ]", question or ""))
    fallback_lang = "ru" if is_cyr else "en"
    if not client:
        # fallback without LLM
        t = user_stats["today"]
        y = user_stats["yesterday"]
        if admin_mode and admin_stats:
            today_org = admin_stats["today"]
            week = admin_stats["week"]
            if fallback_lang == "ru":
                return (
                    f"По организации: сегодня {today_org['total']} звонков, ср.дл {today_org['avg_duration']:.2f} мин; "
                    f"за 7д {week['total']} звонков, ср.дл {week['avg_duration']:.2f} мин. "
                    f"По вам лично: сегодня {t['total']}, вчера {y['total']}."
                )
            return (
                f"Org: today {today_org['total']} calls avg {today_org['avg_duration']:.2f}m; "
                f"7d {week['total']} calls avg {week['avg_duration']:.2f}m. "
                f"You: today {t['total']}, yesterday {y['total']}."
            )
        if fallback_lang == "ru":
            return (
                f"Сегодня звонков: {t['total']}, ср. длительность {t['avg_duration']:.2f} мин. "
                f"Вчера: {y['total']}, ср. длительность {y['avg_duration']:.2f} мин."
            )
        return (
            f"Today calls: {t['total']}, avg duration {t['avg_duration']:.2f} min. "
            f"Yesterday: {y['total']}, avg duration {y['avg_duration']:.2f} min."
        )
    prompt = (
        "Ты телеграм-бот аналитик. Кратко и живо отвечай на том же языке, что запрос (2-4 предложения). "
        "Опирайся только на переданные метрики, не выдумывай числа. "
        "Если пользователь админ, отвечай прежде всего по орг-метрикам (org_stats), а личные метрики (user_stats) используй только если явно спрашивают про себя. "
        "Если данных мало — скажи об этом и уточни, что есть."
    )
    content = {
        "user": user.representative_name,
        "question": question,
        "user_stats": user_stats,
        "org_stats": admin_stats,
    }
    try:
        resp = await asyncio.to_thread(
            client.chat.completions.create,
            model=settings.openai_model,
            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": str(content)},
            ],
            max_tokens=200,
        )
        return resp.choices[0].message.content.strip()
    except Exception:
        t = user_stats["today"]
        y = user_stats["yesterday"]
        if fallback_lang == "ru":
            return (
                f"Сегодня звонков: {t['total']}, ср. длительность {t['avg_duration']:.2f} мин. "
                f"Вчера: {y['total']}, ср. длительность {y['avg_duration']:.2f} мин."
            )
        return (
            f"Today calls: {t['total']}, avg duration {t['avg_duration']:.2f} min. "
            f"Yesterday: {y['total']}, avg duration {y['avg_duration']:.2f} min."
        )


def log_admin_action(admin_chat_id: int, action: str, details: Optional[dict] = None) -> None:
    with get_session() as session:
        admin_user = session.scalar(
            select(User).where(User.telegram_chat_id == str(admin_chat_id))
        )
        log = AdminLog(
            admin_user_id=admin_user.id if admin_user else None,
            action=action,
            details=details or {},
        )
        session.add(log)


def sanitize_phone(value: str) -> Optional[str]:
    digits = "".join(ch for ch in value if ch.isdigit())
    return digits or None


def phone_candidates(digits: str) -> List[str]:
    """Return possible variants (with/without country code) for matching."""
    if not digits:
        return []
    candidates = set()
    candidates.add(digits)
    # UA-style: 380XXXXXXXXX vs 0XXXXXXXXX
    if digits.startswith("380") and len(digits) == 12:
        local = "0" + digits[3:]
        candidates.update({local, "+380" + digits[3:], "+" + digits})
    if digits.startswith("0") and len(digits) == 10:
        intl = "380" + digits[1:]
        candidates.update({intl, "+380" + digits[1:], digits[1:]})
    return list(candidates)


def canonical_phone(digits: str) -> str:
    """Choose canonical storage form (prefer intl 380...)."""
    if digits.startswith("380") and len(digits) == 12:
        return digits
    if digits.startswith("0") and len(digits) == 10:
        return "380" + digits[1:]
    return digits


def ensure_admin_seed(chat_id: int, full_name: str) -> None:
    if str(chat_id) not in settings.telegram_admin_ids:
        return
    with get_session() as session:
        user = session.scalar(
            select(User).where(User.telegram_chat_id == str(chat_id))
        )
        if not user:
            user = User(
                representative_name=full_name or f"admin_{chat_id}",
                phone=str(chat_id),
                telegram_chat_id=str(chat_id),
                is_admin=True,
            )
            session.add(user)
        elif not user.is_admin:
            user.is_admin = True
        session.add(
            AdminLog(
                admin_user_id=user.id if user.id else None,
                action="ensure_admin_seed",
                details={"chat_id": chat_id},
            )
        )


def is_admin(chat_id: int) -> bool:
    if str(chat_id) in settings.telegram_admin_ids:
        return True
    with get_session() as session:
        return bool(
            session.scalar(
                select(User).where(
                    User.telegram_chat_id == str(chat_id), User.is_admin.is_(True)
                )
            )
        )


async def handle_start(message: Message) -> None:
    chat_id = message.chat.id
    full_name = message.from_user.full_name
    ensure_admin_seed(chat_id, full_name)
    with get_session() as session:
        user = session.scalar(
            select(User).where(User.telegram_chat_id == str(chat_id))
        )
    if user:
        role = "админ" if user.is_admin else "пользователь"
        kb = build_main_keyboard(user.is_admin)
        await message.answer(
            f"Привет, {full_name}! Ты {role}.\nКоманды: /last, /settings (для админов).",
            reply_markup=kb,
        )
        return
    kb = ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text="Отправить мой номер", request_contact=True)]],
        resize_keyboard=True,
        one_time_keyboard=True,
    )
    await message.answer(
        "Привет! Нажми кнопку, чтобы отправить свой номер телефона и привязать аккаунт.",
        reply_markup=kb,
    )


async def handle_help(message: Message) -> None:
    await message.answer(
        "Команды:\n"
        "/last [count] [department] — последние записи\n"
        "/settings — настройки (для админов)\n"
        "Бот присылает ежедневные дайджесты после привязки телефона."
    )


def get_last(count: int = 5, department: Optional[str] = None) -> list[Analysis]:
    with get_session() as session:
        stmt = select(Analysis).order_by(Analysis.call_date.desc())
        if department:
            stmt = stmt.where(Analysis.department == department)
        stmt = stmt.limit(min(count, 20))
        return session.scalars(stmt).all()


def format_row(a: Analysis) -> str:
    title = a.title or a.summary or "(без заголовка)"
    if title and len(title) > 180:
        title = title[:177] + "..."
    dur = f"{a.duration_minutes:.2f} мин" if a.duration_minutes else "-"
    return (
        f"#{a.id} | {a.department or '-'} | {a.representative or '-'}\n"
        f"{title}\n"
        f"Дата: {a.call_date} | Длительность: {dur}\n"
        f"Status: {a.status}\n"
        f"Audio: {a.external_url or '—'}"
    )


async def handle_last(message: Message) -> None:
    parts = message.text.split(maxsplit=2)
    count = 5
    department = None
    if len(parts) >= 2:
        try:
            count = int(parts[1])
        except ValueError:
            department = parts[1]
    if len(parts) == 3:
        department = parts[2]
    rows = get_last(count=count, department=department)
    if not rows:
        await message.answer("Нет данных.")
        return
    chunks = []
    for row in rows:
        chunks.append(format_row(row))
    text = "\n\n".join(chunks)
    if len(text) > 3900:
        text = text[:3900] + "\n...\n(обрезано)"
    await message.answer(text)


def build_settings_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Маппинг сотрудников", callback_data="cfg_users")],
            [InlineKeyboardButton(text="Управление админами", callback_data="cfg_admins")],
            [InlineKeyboardButton(text="Список админов", callback_data="cfg_admin_list")],
        ]
    )


def build_main_keyboard(is_admin: bool) -> InlineKeyboardMarkup:
    buttons = [[InlineKeyboardButton(text="Мои 5", callback_data="last5_me")]]
    if is_admin:
        buttons.append([InlineKeyboardButton(text="Настройки", callback_data="cfg_menu")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


async def handle_settings(message: Message) -> None:
    if not is_admin(message.chat.id):
        await message.answer("Нет доступа. Обратитесь к администратору.")
        return
    await message.answer("Настройки:", reply_markup=build_settings_keyboard())


async def handle_callback(query: CallbackQuery) -> None:
    data = query.data or ""
    chat_id = query.message.chat.id
    if data == "cfg_menu":
        await query.message.answer("Настройки:", reply_markup=build_settings_keyboard())
        await query.answer()
        return
    if data == "last5_me":
        with get_session() as session:
            user = session.scalar(select(User).where(User.telegram_chat_id == str(chat_id)))
            rep_filter = user.representative_name if user else None
            rows = (
                session.scalars(
                    select(Analysis)
                    .where(Analysis.call_date.is_not(None))
                    .where(Analysis.representative == rep_filter if rep_filter else True)
                    .order_by(Analysis.call_date.desc())
                    .limit(5)
                ).all()
            )
        if not rows:
            await query.message.answer("Нет данных.")
            await query.answer()
            return
        chunks = []
        for r in rows:
            client = (r.metadata_json or {}).get("Customer") or "-"
            summary = r.summary or r.title or "-"
            link = r.external_url or "-"
            chunks.append(f"{client}\nSummary: {summary}\n{link}")
        text = "\n\n".join(chunks)
        await query.message.answer(text)
        await query.answer()
        return
    if data == "cfg_users":
        with get_session() as session:
            reps = [
                r
                for r in list_representatives(session)
                if r and r.lower() not in {"s", "f"} and len(r) > 1
            ]
        if not reps:
            await query.message.answer("Нет сотрудников в данных.")
            await query.answer()
            return
        buttons = [
            InlineKeyboardButton(text=rep, callback_data=f"map_rep:{rep}") for rep in reps[:50]
        ]
        # chunk rows
        rows: List[List[InlineKeyboardButton]] = []
        for b in buttons:
            if not rows or len(rows[-1]) >= 1:
                rows.append([])
            rows[-1].append(b)
        rows.append([InlineKeyboardButton(text="Отмена", callback_data="cancel_map")])
        kb = InlineKeyboardMarkup(inline_keyboard=rows)
        await query.message.answer("Выберите сотрудника для маппинга:", reply_markup=kb)
        await query.answer()
        return
    if data.startswith("map_rep:"):
        rep = data.split("map_rep:", 1)[1]
        pending_actions[chat_id] = {"type": "map_rep", "rep": rep}
        await query.message.answer(
            f"Введите номер телефона для сотрудника: {rep}\nФормат: 380XXXXXXXXX (12 цифр) или 0XXXXXXXXX.",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="Отмена", callback_data="cancel_map")]]
            ),
        )
        await query.answer()
        return
    if data == "cfg_admins":
        pending_actions[chat_id] = {"type": "add_admin_phone"}
        await query.message.answer(
            "Введите телефон пользователя, чтобы дать права админа.\nФормат: 380XXXXXXXXX (12 цифр) или 0XXXXXXXXX.",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[[InlineKeyboardButton(text="Отмена", callback_data="cancel_admin")]]
            ),
        )
        await query.answer()
        return
    if data == "cancel_map":
        pending_actions.pop(chat_id, None)
        await query.message.answer("Действие отменено.", reply_markup=build_settings_keyboard())
        await query.answer()
        return
    if data == "cancel_admin":
        pending_actions.pop(chat_id, None)
        await query.message.answer("Действие отменено.", reply_markup=build_settings_keyboard())
        await query.answer()
        return
    if data == "cfg_admin_list":
        with get_session() as session:
            admins = session.scalars(
                select(User).where(User.is_admin.is_(True))
            ).all()
        if not admins:
            await query.message.answer("Администраторов нет.")
            await query.answer()
            return
        lines = []
        for a in admins:
            lines.append(f"{a.representative_name or '-'} | {a.phone or '-'} | chat_id={a.telegram_chat_id or '-'}")
        await query.message.answer("\n".join(lines))
        await query.answer()
        return
    if data.startswith("err:"):
        analysis_id = int(data.split("err:", 1)[1])
        await send_error_details(chat_id, analysis_id, query.message)
        await query.answer()
        return
    await query.answer()


async def send_error_details(chat_id: int, analysis_id: int, origin_msg: Optional[Message]) -> None:
    with get_session() as session:
        a = session.scalar(select(Analysis).where(Analysis.id == analysis_id))
    if not a:
        await origin_msg.answer("Запись не найдена.")
        return
    complaints = (a.result_json or {}).get("Скарги клієнта") or (a.result_json or {}).get(
        "Client_Complaints"
    )
    has_complaint = complaints and str(complaints).lower() not in {"no", "false", "0"}
    summary = a.summary or a.title or "(нет summary)"
    call_filter = (a.result_json or {}).get("Call_Filter")
    greeting = (a.result_json or {}).get("Привітання")
    questions = (a.result_json or {}).get("Уточнюючі питання")
    score = get_score(a)
    text_lines = [
        f"#{a.id} | {a.representative or '-'} | {a.department or '-'}",
        f"Оценка: {score if score is not None else '—'} | Call_Filter: {call_filter or '—'}",
        f"Жалобы: {'есть' if has_complaint else 'нет'}",
        f"Уточнюючі питання: {'есть' if questions else 'нет'}",
        f"Привітання: {'есть' if greeting else 'нет'}",
        f"Длительность: {a.duration_minutes or '-'} мин",
        f"Аудио: {a.external_url or '—'}",
        f"Summary: {summary}",
    ]
    text = "\n".join(text_lines)
    try:
        await origin_msg.answer_audio(audio=a.external_url, caption=text)
    except Exception:
        await origin_msg.answer(text)


async def handle_text(message: Message) -> None:
    chat_id = message.chat.id
    pending = pending_actions.get(chat_id)
    if pending and pending.get("type") in {"map_rep", "add_admin_phone"}:
        digits = sanitize_phone(message.text or "")
        if not digits:
            await message.answer("Нужен номер телефона (цифрами).")
            return
        phone = canonical_phone(digits)
        if pending["type"] == "map_rep":
            rep = pending["rep"]
            with get_session() as session:
                user = session.scalar(
                    select(User).where(User.representative_name == rep)
                )
                existing_phone_user = session.scalar(select(User).where(User.phone == phone))
                if user and existing_phone_user and existing_phone_user.id != user.id:
                    # Переназначаем номер: снимаем с прошлого владельца
                    existing_phone_user.phone = None
                    existing_phone_user.telegram_chat_id = None
                if user:
                    user.phone = phone
                elif existing_phone_user:
                    # Переименовываем существующую запись с номером
                    existing_phone_user.representative_name = rep
                else:
                    user = User(
                        representative_name=rep,
                        phone=phone,
                        is_admin=False,
                    )
                    session.add(user)
            log_admin_action(chat_id, "map_rep", {"rep": rep, "phone": phone})
            await message.answer(f"Сохранено. {rep} → {phone}. Попросите сотрудника написать /start для привязки чата.")
            pending_actions.pop(chat_id, None)
            return
        if pending["type"] == "add_admin_phone":
            with get_session() as session:
                user = session.scalar(select(User).where(User.phone == phone))
                if not user:
                    user = User(
                        representative_name=phone,
                        phone=phone,
                        is_admin=True,
                    )
                    session.add(user)
                else:
                    user.is_admin = True
            log_admin_action(chat_id, "add_admin", {"phone": phone})
            await message.answer("Админ добавлен/обновлен. Если чат ещё не привязан — попросите пользователя нажать /start.")
            pending_actions.pop(chat_id, None)
            return
    # чат-ответ на произвольный текст
    with get_session() as session:
        user = session.scalar(select(User).where(User.telegram_chat_id == str(chat_id)))
    if not user:
        await message.answer("Привяжи номер через /start, чтобы я смог отвечать по данным.")
        return
    # быстрые ответы на конкретные запросы (первый звонок сегодня)
    if message.text:
        q = message.text.lower()
        if ("перв" in q and "звон" in q and ("сегод" in q or "today" in q)) or (
            "first" in q and "call" in q and ("today" in q)
        ):
            first = first_call_today()
            if first:
                client = (first.metadata_json or {}).get("Customer") or "-"
                summary = first.summary or first.title or "-"
                url = first.external_url or "-"
                ans = (
                    f"Самый ранний звонок сегодня:\n"
                    f"{first.call_date} | {first.representative or '-'}\n"
                    f"Клиент: {client}\n"
                    f"Summary: {summary}\n"
                    f"Ссылка: {url}"
                )
                await message.answer(ans)
                log_interaction(chat_id, user, message.text or "", ans)
                return
            else:
                ans = "Сегодня ещё нет звонков в базе."
                await message.answer(ans)
                log_interaction(chat_id, user, message.text or "", ans)
                return
        # быстрый ответ на общее количество звонков сегодня
        if "сколь" in q and "звон" in q and ("сегод" in q or "today" in q):
            total_today = count_calls_for_day(0)
            if re.search("[А-Яа-яЁёІіЇїЄєҐґ]", message.text or ""):
                ans = f"Сегодня у компании звонков: {total_today}."
            else:
                ans = f"Today the company has {total_today} calls."
            await message.answer(ans)
            log_interaction(chat_id, user, message.text or "", ans)
            return
        # быстрый ответ на количество звонков вчера
        if ("сколь" in q and "звон" in q and ("вчера" in q or "yesterday" in q)):
            total_yesterday = count_calls_for_day(1)
            if re.search("[А-Яа-яЁёІіЇїЄєҐґ]", message.text or ""):
                ans = f"Вчера у компании звонков: {total_yesterday}."
            else:
                ans = f"Yesterday the company had {total_yesterday} calls."
            await message.answer(ans)
            log_interaction(chat_id, user, message.text or "", ans)
            return
        # быстрый ответ на количество звонков за последние N дней
        match_days = re.search(r"(последн\\w*|last)\\s+(\\d{1,3})\\s+дн|last\\s+(\\d{1,3})\\s+day", q)
        if match_days and "звон" in q:
            num = None
            for g in match_days.groups():
                if g and g.isdigit():
                    num = int(g)
                    break
            if num:
                # если в вопросе упомянуты "по дням" или "какой день" — выведем разбивку
                if "по дн" in q or "какой день" in q or "в какой день" in q or "by day" in q:
                    rows = daily_counts_last_days(num)
                    if not rows:
                        msg = "За этот период нет звонков." if re.search("[А-Яа-яЁёІіЇїЄєҐґ]", message.text or "") else "No calls in this period."
                        await message.answer(msg)
                        log_interaction(chat_id, user, message.text or "", msg, is_error=True, reason="no_calls_period", meta={"days": num})
                        return
                    lines = [f"{r['date']}: {r['calls']}" for r in rows]
                    msg = "\n".join(lines)
                    await message.answer(msg)
                    log_interaction(chat_id, user, message.text or "", msg, meta={"days": num})
                    return
                total = count_calls_last_days(num)
                if re.search("[А-Яа-яЁёІіЇїЄєҐґ]", message.text or ""):
                    ans = f"За последние {num} дней звонков: {total}."
                else:
                    ans = f"Calls in the last {num} days: {total}."
                await message.answer(ans)
                log_interaction(chat_id, user, message.text or "", ans, meta={"days": num})
                return
    # если запрос не про статистику — вежливо отказываем
    if not is_stats_query(message.text or ""):
        if re.search("[А-Яа-яЁёІіЇїЄєҐґ]", message.text or ""):
            ans = "Я отвечаю только по статистике звонков. Если нужна другая функция — напишите администратору."
        else:
            ans = "I only handle call statistics. Please ask an administrator for other requests."
        await message.answer(ans)
        log_interaction(chat_id, user, message.text or "", ans, is_error=True, reason="non_stats_query")
        return
    # tool-calling режим: сначала планировщик, потом инструмент, потом композитор
    planner_cmd = await run_planner(message.text or "", admin_mode=is_admin(chat_id))
    if planner_cmd and planner_cmd.get("action"):
        tool_result = execute_tool(planner_cmd)
        reply = await run_composer(message.text or "", tool_result, lang_ru=bool(re.search("[А-Яа-яЁёІіЇїЄєҐґ]", message.text or "")))
        await message.answer(reply)
        log_interaction(
            chat_id,
            user,
            message.text or "",
            reply,
            is_error=not bool(tool_result.get("result")),
            reason="empty_tool_result" if not bool(tool_result.get("result")) else None,
            meta={"tool": planner_cmd},
        )
        return

    try:
        reply = await build_chat_reply(user, message.text, admin_mode=is_admin(chat_id))
        await message.answer(reply)
        log_interaction(chat_id, user, message.text or "", reply)
    except Exception as exc:
        if re.search("[А-Яа-яЁёІіЇїЄєҐґ]", message.text or ""):
            ans = "Пока не могу обработать этот запрос. Обратитесь к администратору, если нужна такая функция."
        else:
            ans = "I can't handle this request yet. Please ask an administrator if you need this feature."
        await message.answer(ans)
        log_interaction(chat_id, user, message.text or "", ans, is_error=True, reason=f"exception: {exc}")


async def handle_contact(message: Message) -> None:
    chat_id = message.chat.id
    contact = message.contact
    digits = sanitize_phone(contact.phone_number if contact else "")
    if not digits:
        await message.answer("Не удалось прочитать номер телефона.")
        return
    candidates = phone_candidates(digits)
    with get_session() as session:
        user = session.scalar(select(User).where(User.phone.in_(candidates)))
        if not user:
            await message.answer("Твой номер не найден в списке сотрудников. Обратись к администратору.")
            return
        user.telegram_chat_id = str(chat_id)
        if user.phone not in candidates:
            user.phone = canonical_phone(digits)
        role = "админ" if user.is_admin else "пользователь"
        is_admin = user.is_admin
    kb = build_main_keyboard(is_admin)
    await message.answer(
        f"Телефон привязан. Роль: {role}. Дайджесты будут приходить ежедневно.",
        reply_markup=kb,
    )
    pending_actions.pop(chat_id, None)


def format_digest(name: str, phone: str, metrics: Dict[str, Any]) -> str:
    calls_today = metrics["calls_today"]
    avg_dur = metrics["avg_duration"]
    avg_30 = metrics["avg_per_day_30d"]
    delta = calls_today - avg_30
    err_count = len(metrics["errors"])
    return (
        f"📊 Отчёт за сегодня\n"
        f"Сотрудник: {name} ({phone})\n"
        f"Звонков: {calls_today} (среднее 30д: {avg_30:.2f}, Δ={delta:+.2f})\n"
        f"Ср. длительность: {avg_dur:.2f} мин\n"
        f"Проблемные (<4): {err_count}"
    )


def build_errors_keyboard(errors: List[Analysis]) -> Optional[InlineKeyboardMarkup]:
    if not errors:
        return None
    rows = []
    for a in errors[:10]:
        title = a.title or a.summary or f"#{a.id}"
        rows.append(
            [
                InlineKeyboardButton(
                    text=title[:60],
                    callback_data=f"err:{a.id}",
                )
            ]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def send_daily_digests(bot: Bot) -> None:
    with get_session() as session:
        users = session.scalars(
            select(User).where(User.telegram_chat_id.is_not(None))
        ).all()
        for u in users:
            metrics = daily_metrics(session, u.representative_name, settings.report_timezone)
            text = format_digest(u.representative_name, u.phone, metrics)
            kb = build_errors_keyboard(metrics["errors"])
            try:
                await bot.send_message(chat_id=u.telegram_chat_id, text=text, reply_markup=kb)
            except Exception:
                continue


async def digest_scheduler(bot: Bot) -> None:
    tz = pytz.timezone(settings.report_timezone)
    while True:
        now = datetime.now(tz)
        target = now.replace(hour=23, minute=55, second=0, microsecond=0)
        if target <= now:
            target += timedelta(days=1)
        await asyncio.sleep((target - now).total_seconds())
        try:
            await send_daily_digests(bot)
        except Exception:
            continue


async def weekly_scheduler(bot: Bot) -> None:
    if not settings.weekly_report_chat_id:
        return
    tz = pytz.timezone(settings.report_timezone)
    while True:
        now = datetime.now(tz)
        # next Monday 09:00
        days_ahead = (7 - now.weekday()) % 7
        if days_ahead == 0:
            days_ahead = 7
        target = now.replace(hour=9, minute=0, second=0, microsecond=0) + timedelta(
            days=days_ahead
        )
        await asyncio.sleep((target - now).total_seconds())
        try:
            with get_session() as session:
                metrics = weekly_org_metrics(session, settings.report_timezone)
            text_lines = [
                "📈 Еженедельный отчёт",
                f"Звонков за 7д: {metrics['total']}",
                f"Ср. длительность: {metrics['avg_duration']:.2f} мин",
                f"Проблемные (<4): {len(metrics['errors'])}",
                f"Irrelevant: {metrics['irrelevant']}",
            ]
            if metrics["top_reps"]:
                top = ", ".join(f"{name}: {cnt}" for name, cnt in metrics["top_reps"])
                text_lines.append(f"Топ по звонкам: {top}")
            text = "\n".join(text_lines)
            await bot.send_message(chat_id=settings.weekly_report_chat_id, text=text)
        except Exception:
            continue


async def ingest_scheduler() -> None:
    while True:
        try:
            async with _ingest_lock:
                await asyncio.to_thread(ingest_all)
        except Exception:
            pass
        await asyncio.sleep(15 * 60)


async def _main() -> None:
    ensure_schema()
    bot = Bot(token=settings.telegram_bot_token)
    dp = Dispatcher()
    dp.message.register(handle_start, Command("start"))
    dp.message.register(handle_help, Command("help"))
    dp.message.register(handle_last, Command("last"))
    dp.message.register(handle_settings, Command("settings"))
    dp.callback_query.register(handle_callback, F.data)
    dp.message.register(handle_contact, F.contact)
    dp.message.register(handle_text, F.text)
    asyncio.create_task(digest_scheduler(bot))
    asyncio.create_task(weekly_scheduler(bot))
    asyncio.create_task(ingest_scheduler())
    await dp.start_polling(bot)


def start_bot() -> None:
    asyncio.run(_main())
