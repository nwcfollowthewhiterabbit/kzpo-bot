from __future__ import annotations

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import pytz
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import Analysis
from .stats import get_score


def _date_range(
    date_from: Optional[str], date_to: Optional[str], tz: str
) -> Tuple[Optional[datetime], Optional[datetime]]:
    """Parse simple date strings: 'today', 'yesterday', iso date (YYYY-MM-DD)."""
    zone = pytz.timezone(tz)
    now = datetime.now(zone)

    def _parse(value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        val = value.lower()
        if val == "today":
            return now.replace(hour=0, minute=0, second=0, microsecond=0).replace(tzinfo=None)
        if val == "yesterday":
            return (
                now.replace(hour=0, minute=0, second=0, microsecond=0)
                - timedelta(days=1)
            ).replace(tzinfo=None)
        try:
            return datetime.fromisoformat(value).replace(tzinfo=None)
        except Exception:
            return None

    start = _parse(date_from)
    end = _parse(date_to)
    # convenience: if only start provided for "today"/"yesterday", set end accordingly
    if start and not end:
        end = start + timedelta(days=1)
    return start, end


def get_departments(
    session: Session, tz: str, date_from: Optional[str] = None, date_to: Optional[str] = None
) -> Dict[str, Any]:
    start, end = _date_range(date_from, date_to, tz)
    stmt = select(Analysis.department, func.count().label("cnt")).where(
        Analysis.department.is_not(None)
    )
    if start:
        stmt = stmt.where(Analysis.call_date >= start)
    if end:
        stmt = stmt.where(Analysis.call_date < end)
    stmt = stmt.group_by(Analysis.department).order_by(func.count().desc())
    rows = session.execute(stmt).all()
    departments = [{"name": r[0], "calls": r[1]} for r in rows if r[0]]
    return {
        "departments": departments,
        "date_from": date_from,
        "date_to": date_to,
    }


def get_calls(
    session: Session,
    tz: str,
    filters: Optional[Dict[str, Any]] = None,
    sort: Optional[Dict[str, str]] = None,
    limit: int = 5,
) -> Dict[str, Any]:
    filters = filters or {}
    sort = sort or {}
    start, end = _date_range(filters.get("date_from"), filters.get("date_to"), tz)
    stmt = select(Analysis).where(Analysis.call_date.is_not(None))
    if start:
        stmt = stmt.where(Analysis.call_date >= start)
    if end:
        stmt = stmt.where(Analysis.call_date < end)
    if filters.get("department"):
        stmt = stmt.where(Analysis.department == filters["department"])
    if filters.get("representative"):
        stmt = stmt.where(Analysis.representative == filters["representative"])

    sort_field = sort.get("field") or sort.get("by") or "call_date"
    sort_dir = (sort.get("direction") or sort.get("order") or "desc").lower()
    if sort_field == "duration":
        order_col = Analysis.duration_minutes
    elif sort_field == "score":
        order_col = Analysis.result_json  # will sort as JSON, fallback below
    else:
        order_col = Analysis.call_date
    if sort_dir == "asc":
        stmt = stmt.order_by(order_col.asc())
    else:
        stmt = stmt.order_by(order_col.desc())

    stmt = stmt.limit(max(1, min(limit, 50)))
    rows: List[Analysis] = session.scalars(stmt).all()

    calls = []
    for r in rows:
        calls.append(
            {
                "id": r.id,
                "rep": r.representative,
                "department": r.department,
                "client": (r.metadata_json or {}).get("Customer"),
                "date": r.call_date,
                "duration": r.duration_minutes,
                "score": get_score(r),
                "url": r.external_url,
                "summary": r.summary or r.title,
            }
        )
    return {
        "calls": calls,
        "filters": filters,
        "sort": sort,
    }


def get_metrics(
    session: Session,
    tz: str,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    group_by: str = "department",
) -> Dict[str, Any]:
    start, end = _date_range(date_from, date_to, tz)
    if group_by == "date":
        group_column = func.date(Analysis.call_date)
    elif group_by == "representative":
        group_column = Analysis.representative
    else:
        group_column = Analysis.department
    stmt = (
        select(
            group_column.label("group"),
            func.count().label("calls"),
            func.avg(Analysis.duration_minutes).label("avg_duration"),
        )
        .where(Analysis.call_date.is_not(None))
        .group_by(group_column)
    )
    if start:
        stmt = stmt.where(Analysis.call_date >= start)
    if end:
        stmt = stmt.where(Analysis.call_date < end)
    if group_by == "date":
        stmt = stmt.order_by(group_column.asc())
    rows = session.execute(stmt).all()

    data = []
    for grp, calls, avg_dur in rows:
        if not grp:
            continue
        data.append(
            {
                "group": grp,
                "calls": calls,
                "avg_duration": float(avg_dur) if avg_dur is not None else None,
            }
        )
    return {
        "group_by": group_by,
        "rows": sorted(data, key=lambda x: x["calls"], reverse=True),
        "date_from": date_from,
        "date_to": date_to,
    }


def get_call_summary(session: Session, call_id: int) -> Dict[str, Any]:
    row = session.scalar(select(Analysis).where(Analysis.id == call_id))
    if not row:
        return {"call": None}
    return {
        "call": {
            "id": row.id,
            "rep": row.representative,
            "department": row.department,
            "client": (row.metadata_json or {}).get("Customer"),
            "date": row.call_date,
            "duration": row.duration_minutes,
            "score": get_score(row),
            "url": row.external_url,
            "summary": row.summary or row.title,
        }
    }
