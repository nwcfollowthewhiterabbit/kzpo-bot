from datetime import datetime
from typing import Optional

from sqlalchemy import JSON, Float, Integer, String, Text, Index, Boolean, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column

from .db import Base


class Analysis(Base):
    __tablename__ = "analyses"
    __table_args__ = (
        Index("ix_analyses_call_date", "call_date"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    uuid: Mapped[Optional[str]] = mapped_column(String(64))
    task_id: Mapped[Optional[str]] = mapped_column(String(64))
    task_uuid: Mapped[Optional[str]] = mapped_column(String(64))
    project_id: Mapped[int] = mapped_column(Integer, index=True)
    status: Mapped[Optional[str]] = mapped_column(String(32))
    content_type: Mapped[Optional[str]] = mapped_column(String(32))
    model: Mapped[Optional[str]] = mapped_column(String(128))
    processing_time_ms: Mapped[Optional[int]] = mapped_column(Integer)

    department: Mapped[Optional[str]] = mapped_column(String(128), index=True)
    representative: Mapped[Optional[str]] = mapped_column(String(128), index=True)
    prompt_id: Mapped[Optional[int]] = mapped_column(Integer, index=True)
    prompt_name: Mapped[Optional[str]] = mapped_column(String(256))

    call_date: Mapped[Optional[datetime]] = mapped_column()
    communication_date: Mapped[Optional[datetime]] = mapped_column()
    created_at: Mapped[Optional[datetime]] = mapped_column()
    updated_at: Mapped[Optional[datetime]] = mapped_column()

    duration_minutes: Mapped[Optional[Float]] = mapped_column(Float)
    external_url: Mapped[Optional[str]] = mapped_column(Text)

    metadata_json: Mapped[Optional[dict]] = mapped_column(JSON)
    result_json: Mapped[Optional[dict]] = mapped_column(JSON)
    audio_file_json: Mapped[Optional[dict]] = mapped_column(JSON)
    transcription_text: Mapped[Optional[str]] = mapped_column(Text)
    transcription_json: Mapped[Optional[dict]] = mapped_column(JSON)
    tokens_json: Mapped[Optional[dict]] = mapped_column(JSON)

    summary: Mapped[Optional[str]] = mapped_column(Text)
    title: Mapped[Optional[str]] = mapped_column(Text)


class User(Base):
    """Telegram user mapping to representative."""

    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    representative_name: Mapped[str] = mapped_column(String(256), index=True, unique=True)
    phone: Mapped[str] = mapped_column(String(64), unique=True)
    telegram_chat_id: Mapped[Optional[str]] = mapped_column(String(64), index=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )


class AdminLog(Base):
    """Audit log for admin actions."""

    __tablename__ = "admin_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admin_user_id: Mapped[Optional[int]] = mapped_column(ForeignKey("users.id"))
    action: Mapped[str] = mapped_column(Text, nullable=False)
    details: Mapped[Optional[dict]] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
