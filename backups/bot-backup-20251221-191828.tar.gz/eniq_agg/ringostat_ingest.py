from __future__ import annotations

import datetime
import logging
from typing import Any, Dict, List, Optional

from sqlalchemy import select

from .config import settings
from .db import get_session
from .models import RingostatCall
from .ringostat_client import RingostatClient

logger = logging.getLogger(__name__)


def parse_dt(value: str | None) -> Optional[datetime.datetime]:
    if not value:
        return None
    try:
        return datetime.datetime.fromisoformat(value)
    except Exception:
        try:
            return datetime.datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
        except Exception:
            return None


def normalize_phone(val: Optional[str]) -> Optional[str]:
    if not val:
        return None
    digits = "".join(ch for ch in str(val) if ch.isdigit())
    return digits or None


def upsert_call(row: Dict[str, Any]) -> RingostatCall:
    rc = RingostatCall(
        call_id=str(row.get("call_id") or row.get("id") or ""),
        project_id=str(row.get("project_id") or settings.ringostat_project_id or ""),
        direction=row.get("direction"),
        status=row.get("status"),
        start_time=parse_dt(row.get("start_time") or row.get("start")),
        end_time=parse_dt(row.get("end_time") or row.get("end")),
        duration=row.get("duration"),
        talk_time=row.get("talk_time") or row.get("talk"),
        ringing_time=row.get("ringing_time"),
        client_number=normalize_phone(row.get("client_number") or row.get("phone") or row.get("caller_number")),
        contact_name=row.get("contact_name"),
        contact_company=row.get("contact_company"),
        employee_number=normalize_phone(row.get("employee_number") or row.get("sip") or row.get("operator_number")),
        responsible_name=row.get("responsible_name") or row.get("sip_name"),
        record_url=row.get("record_url") or row.get("recording"),
        cost=row.get("call_cost"),
        raw_json=row,
    )
    return rc


def fetch_incremental() -> List[int]:
    """Fetch calls for last 10 minutes and upsert; return new call IDs (db pk)."""
    if not settings.ringostat_token or not settings.ringostat_project_id:
        return []
    client = RingostatClient()
    created_ids: List[int] = []
    now = datetime.datetime.utcnow()
    start = now - datetime.timedelta(minutes=10)
    page = 1
    per_page = 100
    try:
        while True:
            data = client.fetch_calls(start, now, page=page, per_page=per_page)
            rows = data.get("results") or data.get("data") or data.get("items") or []
            meta = data.get("meta") or data.get("pagination") or {}
            total_pages = meta.get("pages") or meta.get("total_pages") or 1
            if not rows:
                break
            ids_in_page = [str(r.get("call_id") or r.get("id")) for r in rows if r.get("call_id") or r.get("id")]
            with get_session() as session:
                existing_ids = set()
                if ids_in_page:
                    existing_ids = {
                        x[0]
                        for x in session.execute(
                            select(RingostatCall.call_id).where(RingostatCall.call_id.in_(ids_in_page))
                        ).all()
                    }
                for r in rows:
                    cid = str(r.get("call_id") or r.get("id") or "")
                    if not cid:
                        continue
                    entity = upsert_call(r)
                    if cid in existing_ids:
                        session.merge(entity)
                    else:
                        session.add(entity)
                        session.flush()
                        created_ids.append(entity.id)
            logger.info("ringostat page %s/%s processed (%s rows)", page, total_pages, len(rows))
            page += 1
            if page > total_pages:
                break
    finally:
        client.close()
    return created_ids
