import os
from dataclasses import dataclass
from typing import Optional, List

from dotenv import load_dotenv


load_dotenv()


@dataclass
class Settings:
    eniq_token: str
    base_url: str
    project_id: int
    start_date: Optional[str]
    end_date: Optional[str]
    status: str
    page_size: int
    with_transcription: bool
    database_url: str
    telegram_bot_token: Optional[str]
    telegram_chat_id: Optional[str]
    telegram_admin_ids: List[str]
    report_timezone: str
    weekly_report_chat_id: Optional[str]
    openai_api_key: Optional[str]
    openai_model: str
    ringostat_token: Optional[str]
    ringostat_project_id: Optional[str]

    @classmethod
    def from_env(cls) -> "Settings":
        token = os.getenv("ENIQ_TOKEN")
        if not token:
            raise RuntimeError("ENIQ_TOKEN is required in environment")
        base_url = os.getenv(
            "ENIQ_BASE_URL", "https://new-api.aicallsupervisor.io/api/v1"
        )
        project_id = int(os.getenv("ENIQ_PROJECT_ID", "209"))
        with_transcription_raw = os.getenv("ENIQ_WITH_TRANSCRIPTION", "1").lower()
        with_transcription = with_transcription_raw in {"1", "true", "yes", "on"}
        admin_ids = [
            x.strip() for x in os.getenv("TELEGRAM_ADMIN_IDS", "").split(",") if x.strip()
        ]
        return cls(
            eniq_token=token,
            base_url=base_url,
            project_id=project_id,
            start_date=os.getenv("ENIQ_START_DATE"),
            end_date=os.getenv("ENIQ_END_DATE"),
            status=os.getenv("ENIQ_STATUS", "completed"),
            page_size=int(os.getenv("ENIQ_PAGE_SIZE", "100")),
            with_transcription=with_transcription,
            database_url=os.getenv("DATABASE_URL", "sqlite:///eniq.db"),
            telegram_bot_token=os.getenv("TELEGRAM_BOT_TOKEN"),
            telegram_chat_id=os.getenv("TELEGRAM_CHAT_ID"),
            telegram_admin_ids=admin_ids,
            report_timezone=os.getenv("REPORT_TZ", "Europe/Kyiv"),
            weekly_report_chat_id=os.getenv("WEEKLY_REPORT_CHAT_ID"),
            openai_api_key=os.getenv("OPENAI_API_KEY"),
            openai_model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            ringostat_token=os.getenv("RINGOSTAT_TOKEN"),
            ringostat_project_id=os.getenv("RINGOSTAT_PROJECT_ID"),
        )


settings = Settings.from_env()
